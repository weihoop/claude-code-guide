# Claude Code 配置包

> 开箱即用的 Claude Code 全局配置，包含权限设置和常用命令。

## 📦 配置包内容

```
claude-config/
├── README.md                    # 本文件 - 安装说明
├── install.sh                   # 自动安装脚本（推荐）
├── settings.simple.json         # 精简版权限配置（推荐新手）
├── settings.full.json           # 完整版权限配置（进阶用户）
├── CLAUDE.template.md           # 全局配置模板
└── commands/                    # 自定义斜杠命令（8个）
    ├── test.md                  # /test - 运行测试并智能分析
    ├── review.md                # /review - 完整代码审查
    ├── update.md                # /update - 智能更新依赖
    ├── build.md                 # /build - 构建并检查错误
    ├── deploy.md                # /deploy - 自动化部署
    ├── push.md                  # /push - 提交并推送代码
    ├── fix.md                   # /fix - 自动修复代码问题
    └── doc.md                   # /doc - 智能更新文档
```

## 🚀 快速安装

### 方式一：自动安装（推荐）

```bash
# 运行安装脚本
bash install.sh
```

#### 🔍 安装脚本说明

**执行流程**：
1. ✅ 显示将要执行的操作和文件覆盖说明
2. ✅ 检查现有配置文件
3. ✅ 自动备份现有配置（如果存在）
4. ✅ 让你选择配置版本（精简版/完整版）
5. ✅ 安装配置文件到 `~/.claude/`
6. ✅ 记录安装日志

**⚠️ 文件覆盖说明**：

| 文件 | 处理方式 |
|------|---------|
| `settings.json` | ❌ **会覆盖** - 先备份，再替换 |
| `commands/*.md` | ❌ **会覆盖** - 8个标准命令会覆盖同名文件 |
| `CLAUDE.md` | ✅ **不会覆盖** - 如果已存在，保持不变 |
| 自定义命令 | ✅ **保留** - 不同文件名的命令会保留 |

**🛡️ 备份机制**：

所有现有配置会自动备份到：
```
~/.claude/backup-YYYYMMDD-HHMMSS/
├── settings.json
├── CLAUDE.md
└── commands/
```

恢复命令：
```bash
cp -r ~/.claude/backup-YYYYMMDD-HHMMSS/* ~/.claude/
```

**📝 安装日志**：

所有操作记录到：`~/.claude/install.log`

### 方式二：手动安装

如果你想自己选择安装哪些文件：

#### 1. 安装 settings.json（二选一）

```bash
# 精简版（推荐新手）
cp settings.simple.json ~/.claude/settings.json

# 或完整版（进阶用户）
cp settings.full.json ~/.claude/settings.json
```

#### 2. 安装斜杠命令

```bash
# 创建 commands 目录（如果不存在）
mkdir -p ~/.claude/commands

# 复制所有命令
cp commands/*.md ~/.claude/commands/
```

#### 3. 安装 CLAUDE.md（可选）

```bash
# 如果你还没有全局配置，可以使用模板
cp CLAUDE.template.md ~/.claude/CLAUDE.md

# 然后根据个人需求编辑
vim ~/.claude/CLAUDE.md
```

## 📋 配置说明

### settings.simple.json（精简版）

**适合人群**: 新手、不熟悉权限系统的用户

**权限范围**:
- ✅ 基础文件读写（Read、Write、Edit）
- ✅ 搜索功能（Grep、Glob）
- ✅ 基础 Git 操作（add、commit、push、status、diff、log、fetch）
- ✅ 网络搜索（WebSearch）
- ✅ 常用文件查看命令（cat、find、grep）

**安全特点**:
- ⛔ 禁止: 无特殊禁止项
- ❓ 需要确认: 无特殊确认项

### settings.full.json（完整版）

**适合人群**: 进阶用户、需要更多权限的开发者

**权限范围**:
- ✅ 完整的文件操作权限
- ✅ 详细的系统命令权限（ls、cat、head、tail、grep、awk、sed 等）
- ✅ 系统监控命令（ps、top、htop、lsof、netstat 等）
- ✅ 网络工具（curl、wget、ping、dig 等）
- ✅ 开发工具（git、npm、pip、docker 等）

**安全特点**:
- ⛔ 禁止: 危险操作（rm -rf、sudo、系统重启、用户管理、数据库删除等）
- ❓ 需要确认: 敏感操作（服务管理、文件操作、依赖安装、数据库操作等）

## 🎯 使用斜杠命令

安装完成后，在任意项目中启动 Claude Code：

```bash
claude
```

然后就可以使用斜杠命令：

```bash
# 运行测试
> /test

# 代码审查
> /review

# 构建项目
> /build

# 提交代码
> /push

# 修复代码问题
> /fix

# 更新依赖
> /update

# 部署到指定环境
> /deploy production

# 更新文档
> /doc
```

## 🔧 自定义配置

### 修改 settings.json

编辑 `~/.claude/settings.json` 可以自定义权限：

```bash
vim ~/.claude/settings.json
```

**权限语法**:
```json
{
  "permissions": {
    "allow": ["Read", "Write", "Bash(git:*)"],
    "deny": ["Bash(rm:*)"],
    "ask": ["Bash(npm install:*)"]
  }
}
```

**权限优先级**: `deny > ask > allow`

### 修改 CLAUDE.md

编辑 `~/.claude/CLAUDE.md` 可以自定义全局提示词：

```bash
vim ~/.claude/CLAUDE.md
```

添加你的个人开发偏好、团队规范、常用工具等。

### 自定义斜杠命令

在 `~/.claude/commands/` 目录下创建 `.md` 文件：

```bash
# 创建新命令
vim ~/.claude/commands/mycommand.md
```

文件格式：
```markdown
---
name: mycommand
description: 我的自定义命令
aliases: [mc, my]
---

# 命令标题

命令的详细说明和执行步骤。
```

## 🆚 两个版本对比

| 特性 | settings.simple.json | settings.full.json |
|------|---------------------|-------------------|
| **适合人群** | 新手 | 进阶用户 |
| **allow 规则数** | 11 条 | 111 条 |
| **deny 规则数** | 0 条 | 57 条 |
| **ask 规则数** | 0 条 | 62 条 |
| **安全级别** | 中 | 高（有大量禁止项） |
| **灵活性** | 低 | 高 |
| **上手难度** | ⭐ 简单 | ⭐⭐⭐ 需要理解 |

**建议**:
- 🔰 如果你是新手，先用 `settings.simple.json`
- 🚀 熟悉后，可以切换到 `settings.full.json` 或自己定制

## 📚 相关文档

- [Claude Code 官方文档](https://docs.anthropic.com/claude-code)
- [Claude Code 中文手册](https://github.com/weihoop/claude-code-guide)
- [权限配置完整指南](https://github.com/weihoop/claude-code-guide/blob/main/docs/configuration/permissions.md)
- [项目配置模板](https://github.com/weihoop/claude-code-guide/tree/main/docs/templates)

## 🐛 常见问题

### Q: 安装后配置不生效？

重启 Claude Code：
```bash
# 退出当前会话
exit 或 Ctrl+D

# 重新启动
claude
```

### Q: 如何恢复之前的配置？

自动安装会在 `~/.claude/backup-YYYYMMDD-HHMMSS/` 创建备份：
```bash
# 查看备份
ls ~/.claude/backup-*/

# 恢复备份
cp ~/.claude/backup-YYYYMMDD-HHMMSS/settings.json ~/.claude/
```

### Q: 如何切换配置版本？

直接替换 `settings.json`：
```bash
# 切换到精简版
cp settings.simple.json ~/.claude/settings.json

# 切换到完整版
cp settings.full.json ~/.claude/settings.json

# 重启 Claude Code
```

### Q: commands 命令没有显示？

检查文件权限：
```bash
chmod 600 ~/.claude/commands/*.md
```

### Q: 想要自定义部分配置怎么办？

1. 选择一个基础版本安装
2. 编辑 `~/.claude/settings.json` 添加你的规则
3. 保存并重启 Claude Code

## 💡 提示

- ⭐ 建议先从 `settings.simple.json` 开始
- ⭐ 定期备份你的配置文件
- ⭐ 查看 [中文手册](https://github.com/weihoop/claude-code-guide) 了解更多用法
- ⭐ 项目级配置可以覆盖全局配置

## 🤝 反馈与贡献

如有问题或建议，欢迎在 [GitHub Issues](https://github.com/weihoop/claude-code-guide/issues) 提出。

---

**祝使用愉快！** 🎉
